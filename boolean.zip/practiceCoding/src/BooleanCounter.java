import java.util.Scanner;
public class BooleanCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num;
        System.out.print("Enter the number of booleans: ");
        num = Integer.parseInt(scanner.next());

        boolean[] boolArray = new boolean[num];
        int boolNum;
        int trueNum = 0;

        System.out.println("Enter '1' for true, or '0' for 'false'\n");
        for(int i = 0; i < num; i++) {
            System.out.printf("Enter boolean %d: ", i + 1);
            boolNum = Integer.parseInt(scanner.next());
            if(boolNum == 1) {
                boolArray[i] = true;
                trueNum++;
            } else {
                boolArray[i] = false;
            }
        }

        System.out.print("boolArray = [");
        for (int i = 0; i < boolArray.length - 1; i++) {
            System.out.printf("%b, ", boolArray[i]);
        }
        System.out.printf("%b] -> %d", boolArray[boolArray.length - 1], trueNum);

    }
}
